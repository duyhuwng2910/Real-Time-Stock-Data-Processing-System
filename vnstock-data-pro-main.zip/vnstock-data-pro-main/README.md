# vnstock-data-pro

> Gói phần mềm nâng cao chocho thư viện vnstock cung cấp khả năng truy xuất dữ liệu có độ tin cậy cao.

## Lịch sử cập nhật
- Online: Xem [tại đây](https://github.com/vnstock-hq/vnstock-data-pro/blob/main/changes_log.md)
- Offline: Xem file `changes_log.md` tại thư mục gốc. Mở bằng Notepad hoặc ứng dụng đọc văn bản bất kỳ như Visual Studio Code.

## Hướng dẫn cài đặt phần mềm

> Bạn có thể chọn một trong hai cách cài đặt thư viện như dưới đây.

### Sử dụng Git

> Git là công cụ quản lý mã nguồn phổ biến nhất hiện nay. Git không có sẵn trên Windows nên bạn có thể cần download và cài đặt thêm [tại đây](https://git-scm.com/downloads). Nếu bạn sử dụng thư viện trên môi trường Google Colab, đây là cách khuyên dùng.

Bạn cần thực hiện các bước sau để cài đặt mã nguồn từ Git:

1. Tạo Github personal access token (mã bảo mật sử dụng cho nhà phát triển) để truy cập private repo [tại đây](https://github.com/settings/tokens/new). Bắt buộc chọn mục `Tokens(classic)` như link này.
2. Đặt tên cho token, chọn 2 quyền bắt  buộc là `repo` và `read:packages`. Sau đó nhấn nút `Generate token` để tạo token như hình minh họa. Tham khảo mô tả chi tiết các quyền [tại đây](https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/scopes-for-oauth-apps#available-scopes)
![](/docs/attachments/install-python-from-git-private-repo.jpg)
3. Copy token vừa được tạo ra thay thế đoạn `{github_personal_access_token_của_bạn}` trong dòng lệnh đưới đây và chạy trong Terminal/Command Prompt hoặc trong Jupyter Notebook.
  ```
  pip install git+https://vnstock-hq:{github_personal_access_token_của_bạn}@github.com/vnstock-hq/vnstock-data-pro.git
  ```
Trong đó, `vnstock-hq` là tên tài khoản Github của nhóm phát triển, `vnstock-data-pro` là tên repo mã nguồn.

### Sử dụng file ZIP

> Cách này thích hợp cho bạn nào không muốn sử dụng Git hoặc chỉ muốn dùng thư viện ở môi trường cục bộ.

- Chọn mục Code (ngay phía trên danh sách mã nguồn)
  
- Tải mã nguồn với mục Download ZIP
  ![](/docs/attachments/vnstock-advanced-data-download-code.png)

- Chạy Terminal/Command Prompt và mở thư mục chứa file vừa download về. Ví dụ, thư mục Downloads trên Windows
  
  ```
  cd Downloads
  ```

- Chạy câu lệnh cài đặt với pip
  
  ```
  pip install vnstock-data-pro-main.zip
  ```

## Nâng cấp thư viện
- Bạn có thể gỡ cài đặt thư viện bằng cách chạy lệnh sau trong Terminal/Command Prompt hoặc trong Jupyter Notebook sau đó thực hiện cài đặt phiên bản mới từ file zip hoặc sử dụng token.
  ```
  pip uninstall vnstock-data-pro
  ```

Nếu câu lệnh trên không hoạt động, hãy thử `pip uninstall vnstock-advanced-data` là tên gọi của gói phần mềm này thời kỳ đầu.

## Sử dụng SSI Fast Connect Data
- Online: Đọc hướng dẫn vnstock docs [tại đây](https://docs.vnstock.site/integrate/ssi_fast_connect_api/) hoặc tại Github [tại đây](https://github.com/vnstock-hq/vnstock-data-pro/blob/main/docs/guide/SSI_Fast_Connect_Data.md)
- Offline: Truy cập hướng dẫn tại đường dẫn: `docs/guide/SSI_Fast_Connect_Data.md`
## Sử dụng Pytesseract OCR
- Online: Đọc hướng dẫn vnstock docs [tại đây](https://docs.vnstock.site/integrate/pytesseract-ocr-chuyen-doi-tai-lieu-tai-chinh-scan-sang-van-ban)
- Sử dụng demo notebook tại thư mục: `docs/pytesseract_ocr_scanned_documents_to_text.ipynb`