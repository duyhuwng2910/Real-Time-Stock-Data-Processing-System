from .settings import *

columns_mapping = {
    'Ngay': 'date',
    'KLGDRong': 'net_volume',
    'GTDGRong': 'net_value',
    'ThayDoi': 'change',
    'KLMua': 'buy_volume',
    'GtMua': 'buy_value',
    'KLBan': 'sell_volume',
    'GtBan': 'sell_value',
    'RoomConLai': 'remain_room',
    'DangSoHuu': 'current_volume',
    'Symbol': 'symbol',
    'Date': 'date',
    'KLcpMua': 'buy_volume',
    'KlcpBan': 'sell_volume',
    'GtMua': 'buy_value',
    'GtBan': 'sell_value',
    'MaCK': 'symbol'
}

def foreign_trade_data(symbol='VNINDEX', start_date='2023-01-01', end_date='2023-12-22', limit=500, page=1, lang='en', headers=cf_headers):
    """
    A function to extract foreign trade data from cafef.vn

    Parameters:
    symbol (str): a stock symbol or index such as VNINDEX.
    start_date (str): start date in YYYY-MM-DD format.
    end_date (str): end date in YYYY-MM-DD format.
    limit (int): number of records per page. Prioritize increasing this number to reduce the number of requests.
    page (int): page number.
    lang (str): language of column names. Either 'en' or 'vi'.
    headers (dict): headers for request.
    """
    # convert start_date and end_date to datetime object
    start_date = convert_date(start_date, output_format='%d/%m/%Y')
    end_date = convert_date(end_date, output_format='%d/%m/%Y')

    # convert lang to lower case
    lang = lang.lower()
    # check if lang is valid
    if lang not in ['en', 'vi']:
        raise ValueError("`lang` parameter must be either 'en' or 'vi'")
    
    url = f"https://s.cafef.vn/Ajax/PageNew/DataHistory/GDKhoiNgoai.ashx?Symbol={symbol}&StartDate={start_date}&EndDate={end_date}&PageIndex={page}&PageSize={limit}"
    response = requests.request("GET", url, headers=headers)
    # if status code is 200, return json data
    if response.status_code == 200:
        data = response.json()
        # print total count of records
        df = pd.DataFrame(data['Data']['Data'])
        # add symbol column
        df['MaCK'] = symbol
        print(f"Total records: {data['Data']['TotalCount']}. Returned records: {len(df)}")
        # if lang is vi, skip columns mapping, else map columns to english
        if lang == 'vi':
            return df
        elif lang == 'en':
            return df.rename(columns=columns_mapping)
    else:
        return None
    

def proprietary_trade_data(symbol='VNINDEX', start_date='2023-01-01', end_date='2023-12-22', limit=500, page=1, lang='en', headers=cf_headers):
    """
    A function to extract proprietary trade data from cafef.vn

    Parameters:
        symbol (str): a stock symbol or index such as VNINDEX.
        start_date (str): start date in YYYY-MM-DD format.
        end_date (str): end date in YYYY-MM-DD format.
        limit (int): number of records per page. Prioritize increasing this number to reduce the number of requests.
        page (int): page number.
        lang (str): language of column names. Either 'en' or 'vi'.
        headers (dict): headers for request.
    Returns:
        df (pandas.DataFrame): a pandas dataframe containing proprietary trade data.
        Unit of volume is 1 shares. Unit of value is 1 VND.
    """
    # convert start_date and end_date to datetime object
    start_date = convert_date(start_date, output_format='%m/%d/%Y')
    end_date = convert_date(end_date, output_format='%m/%d/%Y')

    # convert lang to lower case
    lang = lang.lower()
    # check if lang is valid
    if lang not in ['en', 'vi']:
        raise ValueError("`lang` parameter must be either 'en' or 'vi'")
    
    url = f"https://s.cafef.vn/Ajax/PageNew/DataHistory/GDTuDoanh.ashx?Symbol={symbol}&StartDate={start_date}&EndDate={end_date}&PageIndex={page}&PageSize={limit}"
    response = requests.request("GET", url, headers=headers)
    # if status code is 200, return json data
    if response.status_code == 200:
        data = response.json()
        # print total count of records
        df = pd.DataFrame(data['Data']['Data']['ListDataTudoanh'])
        # rename Symbol to MaCK
        df = df.rename(columns={'Symbol': 'MaCK', 'Date': 'Ngay'})
        # move MaCK to be the last column
        cols = list(df.columns)
        cols.remove('MaCK')
        df = df[cols + ['MaCK']]
        print(f"Total records: {data['Data']['TotalCount']}. Returned records: {len(df)}")
        # if lang is vi, skip columns mapping, elif map columns to english
        if lang == 'vi':
            return df
        elif lang == 'en':
            return df.rename(columns=columns_mapping)
    else:
        return None