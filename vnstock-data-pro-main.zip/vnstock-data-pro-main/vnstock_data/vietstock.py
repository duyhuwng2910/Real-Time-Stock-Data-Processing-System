import requests
import pandas as pd

mbke_headers = {
  'Accept': '*/*',
  'Accept-Language': 'en-US,en;q=0.9,vi-VN;q=0.8,vi;q=0.7',
  'Cache-Control': 'no-cache',
  'Connection': 'keep-alive',
  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
  'DNT': '1',
  'Origin': 'https://data.mbke.com.vn',
  'Pragma': 'no-cache',
  'Referer': 'https://data.mbke.com.vn/ACB/tai-tai-lieu.htm?doctype=8',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-origin',
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'X-Requested-With': 'XMLHttpRequest',
  'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
  'sec-ch-ua-mobile': '?0',
  'sec-ch-ua-platform': '"Windows"'
}

def document_type_list (headers=mbke_headers):
    """Get the list of document types from Maybank using Vietstock data"""
    url = "https://data.mbke.com.vn/data/getdocumenttype"
    response = requests.request("GET", url, headers=headers)
    if response.status_code == 200:
        df = pd.DataFrame(response.json())
        # drop DisplayOrder column
        df = df.drop(columns=['DisplayOrder'])
        return df
    else:
        return None
    
def financial_document_search(symbol="ACB", **kwargs):
    """
    Get scanned financial document links to download from Maybank using Vietstock Finance data

    Parameters:
        symbol (str): a stock symbol or index such as VNINDEX.
        **kwargs (optional): any additional keyword arguments like "type" and "year" for filtering documents. For example type = 1 and year = 2023 where type is the document type can be obtained from `document_type_list` function.
    Returns:
        pd.DataFrame: a pandas DataFrame containing document information, or None if request fails.
    """
    url = "https://data.mbke.com.vn/data/getdocument"
    payload = {"code": symbol}
    # Add any provided kwargs to the payload
    for key, value in kwargs.items():
        if value is not None:
            payload[key] = value
    # payload = urllib.parse.urlencode(payload)
    response = requests.request("POST", url, headers=mbke_headers, data=payload)
    if response.status_code == 200:
        data = response.json()
        df = pd.DataFrame(data)
        return df
    else:
        return None