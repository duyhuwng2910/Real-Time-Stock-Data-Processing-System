from datetime import datetime, timedelta
from pytz import timezone


def parse_timestamp(time_value):
    """
    Convert a datetime object or a string representation of time to a Unix timestamp
    Parameters:
        time_value (datetime or string): A datetime object or a string representation of time
    """
    try:
        if isinstance(time_value, datetime):
            # Localize the datetime object to Ho Chi Minh timezone using pytz
            time_value = timezone('Asia/Ho_Chi_Minh').localize(time_value)
        elif isinstance(time_value, str):
            # Check if the timestamp string contains a time component in HH:MM or HH:MM:SS format
            if ' ' in time_value and ':' in time_value.split(' ')[1]:
                try:
                    time_value = datetime.strptime(time_value, '%Y-%m-%d %H:%M:%S')
                except:
                    time_value = datetime.strptime(time_value, '%Y-%m-%d %H:%M')
            else:
                time_value = datetime.strptime(time_value, '%Y-%m-%d')
        else:
            print("Invalid input type. Supported types are datetime or string.")
            return None

        timestamp = int(time_value.timestamp())
        return timestamp

    except ValueError:
        print("Invalid timestamp format")
        return None
    
def last_n_days(n):
    """
    Return a date value in YYYY-MM-DD format for last n days. If n = 0, return today's date.
    """
    date_value = (datetime.today() - timedelta(days=n)).strftime('%Y-%m-%d')
    return date_value

def time_in_date_string(time_string, print_errors=True):
    """
    Check if a time component is present in the input string.
    
    Parameters:
        time_string (str): A string representation of time
        print_errors (bool): Whether to print errors when encountered
        
    Returns:
        bool: True if time component is present and valid, False otherwise
    """
    try:
        # Attempt to split the string into date and time components
        date_part, time_part = time_string.split(' ')
        
        # Check for the presence of time component
        if ':' in time_part:
            # Split time_part into hours, minutes, and seconds components
            hours, minutes, *seconds = map(int, time_part.split(':'))
            
            # Check if hours, minutes, and seconds are within valid ranges
            if 0 <= hours <= 23 and 0 <= minutes <= 59 and all(0 <= s <= 59 for s in seconds):
                return True
            else:
                if print_errors:
                    print("Invalid time components.")
                return False
        else:
            return False
    except ValueError:
        # Unable to split into date and time components, assuming it's a date only
        if print_errors:
            print("Unable to split into date and time components. Assuming it's a date only.")
        return False