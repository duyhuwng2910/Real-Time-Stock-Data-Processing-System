from pandas import json_normalize
import pandas as pd
import json
import time
from ssi_fc_data import fc_md_client , model
from ssi_fc_data.fc_md_stream import MarketDataStream
from ssi_fc_data.fc_md_client import MarketDataClient

# import config
# client = fc_md_client.MarketDataClient(config)

# MARKET DATA API

def securities_list(client, config, market='HOSE', page=1, size=1000):
    """
    Get list of securities
    Parameters:
    exchange (str): Exchange name
    page (int): page index. Default is 1
    pageSize (int): page size. Default is 1000
    """
    req = model.securities(market, page, size)
    response = client.securities(config, req)
    print(f'Total records: {response["totalRecord"]}')
    df = pd.DataFrame(response['data'])
    return df


def get_securities_details(client, config, symbol='ACB', market='HOSE', page=1, pageSize=100):
    """
    Get details of a stock ticker
    Parameters:
        symbol (str): stock ticker
        market (str): market name. Available values: HOSE, HNX, UPCOM, HNXBOND (Trái phiếu), DER (Phái sinh)
        page (int): page index. Default is 1
        pageSize (int): page size. Default is 1000
    """
    req = model.securities_details(market, symbol, page, pageSize)
    response = client.securities_details(config, req)['data']
    df = json_normalize(response[0]['RepeatedInfo'])
    df['ReportDate'] = response[0]['ReportDate']
    # drop na columns
    df = df.dropna(axis=1, how='all')
    return df

def get_index_list(client, config, exchange='', page=1, pageSize=100):
    """
    List all index codes and names
    Parameters:
        exchange (str, optional): HOSE, HNX. If not specify then returns all exchanges
    """
    req = model.index_list(exchange, page, pageSize)
    response = client.index_list(config, req)['data']
    df = json_normalize(response)
    return df



def get_index_component(client, config, index='VN30', page=1, pageSize=100):
    """
    Get the list of symbols in an index
    Parameters:
    index (str, required): index code such as VN30, VN100
    page (int): page index. Default is 1
    pageSize (int): page size. Default is 1000
    """
    req = model.index_components(index, page, pageSize)
    response = client.index_components(config, req)['data'][0]
    code = response['IndexCode']
    exchange = response['Exchange']
    total = response['TotalSymbolNo']
    print(f'Index: {code} - {exchange}. Total {total} symbols')
    df = json_normalize(response['IndexComponent'])
    # drop column Isin
    df = df.drop(columns=['Isin'])
    return df

def get_daily_ohlc(client, config, symbol='SSI', fromDate='01/07/2023', toDate='31/07/2023', ascending=True, page=1, pageSize=1000):
    """
    Get daily OHLC data
    Parameters:
        symbol (str): symbol
        fromDate (str): from date (dd/MM/yyyy). If not specify, get today date
        toDate (str): to date (dd/MM/yyyy). If not specify, get today date
        page (int): page index. Default is 1
        pageSize (int): page size. Default is 1000
        ascending (bool): ascending or descending. Default: True
    """
    req = model.daily_ohlc(symbol, fromDate, toDate, page, pageSize, ascending)
    response = client.daily_ohlc(config, req)['data']
    df = json_normalize(response)
    # drop column Time
    df = df.drop(columns=['Time'])
    return df

def get_intraday_ohlc(client, config, symbol='SSI', fromDate='25/07/2023', toDate='31/07/2023', page=1, pageSize=1000, ascending=True, resolution=1):
    """
    Get daily OHLC data
    Parameters:
        symbol (str): symbol
        fromDate (str): from date (dd/MM/yyyy). If not specify, get today date
        toDate (str): to date (dd/MM/yyyy). If not specify, get today date
        ascending (bool): ascending or descending. Default: True
        resolution (int): group by 1 minute.
        page (int): page index. Default is 1
        pageSize (int): page size. Default is 1000
    """
    req = model.intraday_ohlc(symbol, fromDate, toDate, page, pageSize, ascending, resolution)
    response = client.intraday_ohlc(config, req)
    df = json_normalize(response['data'])
    return df

def get_daily_index(client, config, index='VN30', fromDate='25/07/2023', toDate='31/07/2023', page=1, pageSize=1000, orderBy='Tradingdate', order='desc', request_id=''):
    """
    Return daily index data
    Parameters:
        index (str): index name. Valid values can be queried by get_index_list() function.
        fromDate (str): start date of the query in format dd/MM/yyyy
        toDate (str): end date of the query in format dd/MM/yyyy
        page (int): page index
        pageSize (int): page size
        orderBy (str): order by column. Default is Tradingdate
        order (str): order type. Default is desc (descending)
        request_id (str): default is empty string.
    """
    req = model.daily_index(request_id, index, fromDate, toDate, page, pageSize, orderBy, order)
    response = client.daily_index(config, req)['data']
    df = json_normalize(response)
    # drop na columns
    df = df.dropna(axis=1, how='all')
    return df

# Trading session value:
    # - ATO: ATO
    # - LO: Continuous 
    # - ATC: ATC
    # - PT: Putthrough 
    # - BREAK: lunch break
    # - C: Market Close
    # - H: Market halted


def get_daily_stock_price(client, config, symbol='SSI', fromDate='25/07/2023', toDate='31/07/2023', page=1, pageSize=1000, market=''):
    """
    Get daily stock price
    Parameters:
        symbol (str, required): symbol of Stock, CW or Derivatives
        fromDate (str, required): from date. Format: dd/MM/yyyy
        toDate (str, required): to date. Format: dd/MM/yyyy
        page (int, optional): page index
        pageSize (int, optional): page size
        market (str, optional): Identify what market for that symbol:  HOSE, HNX, UPCOM, DER, BOND
    """
    req = model.daily_stock_price(symbol, fromDate, toDate, page, pageSize, market)
    response = client.daily_stock_price(config, req)['data']
    df = json_normalize(response)
    return df


# STREAMING DATA
content_df = pd.DataFrame()

def get_market_data(message, interval=2, items=15, env='Jupyter'):
    """
    Processes market data message and updates the DataFrame.

    Args:
        message (dict): The market data message.
        interval (int, optional): The sleep interval between updates. Defaults to 2 seconds.
        items (int, optional): The number of items to display. Defaults to 15.
        env (str, optional): The environment to display the DataFrame. Defaults to 'Jupyter'. Other option is 'terminal'.
    Returns:
        None
    """
    if env == 'Jupyter':
        from IPython.display import display, clear_output
    elif env == 'terminal':
        pass
    global content_df
    content_str = message['Content']  # Retrieve the content as a string
    content_dict = json.loads(content_str)  # Convert the string to a dictionary
    df = json_normalize(content_dict)
    # drop all columns that is all 0.0 or NaN or mixed of 0.0 and NaN
    df = df.dropna(axis=1, how='all')
    df = df.loc[:, (df != 0).any(axis=0)]
    content_df = pd.concat([content_df, df])
    # reset index
    content_df = content_df.reset_index(drop=True).tail(items)
    display(content_df.T)
    time.sleep(interval)
    try:
        clear_output(wait=True)
    except:
        pass

def getError(error):
    """
    Handles errors during market data stream.

    Args:
        error (Exception): The error object.

    Returns:
        None
    """
    print(error)


def start_market_data_stream(config, channel='X-QUOTE:VN30F2311'):
    """
    Starts the market data stream for the specified channel.

    Args:
        config (dict): The configuration dictionary.
        channel (str, optional): The channel to subscribe to. Defaults to 'X-QUOTE:VN30F2311'.

    Returns:
        None
    """
    mm = MarketDataStream(config, MarketDataClient(config))
    mm.start(get_market_data, getError, channel)
    # message = None
    # while message != "exit()":
    #     message = input(">> ")
    #     if message is not None and message != "" and message != "exit()":
    #         mm.swith_channel(message)
    
