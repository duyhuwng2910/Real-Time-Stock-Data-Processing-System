# Copyright 2023 Thinh Vu @ GitHub

from vnstock.technical import *
from .settings import *
from .utils import *

## WRAPPER FUNCTIONS
def stock_historical_data (symbol='TCB', start_date='2023-06-01', end_date='2023-06-17', resolution='1D', type='stock', beautify=True, decor=False, source='DNSE'): # DNSE source (will be published on vnstock)
    """
    Get historical price data from entrade.com.vn. The unit price is VND.
    Parameters:
        symbol (str): ticker of a stock or index. Available indices are: VNINDEX, VN30, HNX, HNX30, UPCOM, VNXALLSHARE, VN30F1M, VN30F2M, VN30F1Q, VN30F2Q
        from_date (str): start date of the historical price data
        to_date (str): end date of the historical price data
        resolution (str): resolution of the historical price data. Default is '1D' (daily), other options are '1' (1 minute), 15 (15 minutes), 30 (30 minutes), '1H' (hourly). For stock, the limit of 90 days is applied to resolution 1, 15, 30, 1H.
        type (str): stock, index, or derivative. Default is 'stock'
        beautify (bool): if True, convert open, high, low, close to VND for stock symbols. Default is True which means the unit price is thousands VND
        decor (bool): if True, rename columns to Title Case (Open, High, Low, Close instead of open, high, low, close) and set Time column as index. Default is False. This option help to integrate vnstock with other libraries such as TA-Lib out of the box.
        source (str): data source. Default is 'DNSE' EntradeX, other options are 'TCBS' (Only applicable for the `Day` resolution, longterm data)
        headers (dict): headers of the request
    Returns:
        :obj:`pandas.DataFrame`:
        | time | open | high | low | close | volume |
        | ----------- | ---- | ---- | --- | ----- | ------ |
        | YYYY-mm-dd  | xxxx | xxxx | xxx | xxxxx | xxxxxx |
    """
    if source.upper() == 'DNSE':
        df = ohlc_data(symbol, start_date, end_date, resolution, type, headers=entrade_headers)
    elif source.upper() == 'TCBS':
        if resolution == '1D':
            resolution = 'D'
            df = longterm_ohlc_data(symbol, start_date, end_date, resolution, type, headers=tcbs_headers)
        else:
            print('TCBS only support longterm daily data. Please set resolution to 1D')
            return None
    elif source.upper() == 'SSI':
        df = ssi_ohlc(symbol, start_date, end_date, resolution, decor=False, headers=ssi_headers).reset_index()
    elif source.upper() == 'HSC':
        df = hsc_ohlc(symbol, resolution, start_date, end_date, decor=False, headers=hsc_headers).reset_index()
    elif source.upper() == 'VND':
        df = vnd_ohlc(symbol, start_date, end_date, resolution, decor=False, headers=vnd_headers).reset_index()
    # add a source='auto' to optimize the query by choosing the best source
    
    df = df[['time', 'open', 'high', 'low', 'close', 'volume', 'ticker']]
    if beautify:
        if type == 'stock':
            df[['open', 'high', 'low', 'close']] = df[['open', 'high', 'low', 'close']] * 1000
            # convert open, high, low, close to int
            df[['open', 'high', 'low', 'close']] = df[['open', 'high', 'low', 'close']].astype(int)
    if decor == True:
        # Rename columns to Titlecase
        df.columns = df.columns.str.title()
        # set time as index
        df = df.set_index('Time')
    return df

## CHILDREN FUNCTIONS

def ssi_ohlc (symbol='SSI', start_date='2023-06-01', end_date='2023-06-17', resolution='1D', decor=False, headers=ssi_headers):
    """
    Get Candlestick historical data from SSI API.
    Parameters:
        symbol (str): stock symbol
        start_date (str): start date, format YYYY-MM-DD or even with time component YYYY-MM-DD HH:MM:SS, or YYYY-MM-DD HH:MM. When contains time, consider using it with resolution is 1D only.
        end_date (str): end date, format YYYY-MM-DD or even with time component YYYY-MM-DD HH:MM:SS, or YYYY-MM-DD HH:MM. When contains time, consider using it with resolution is 1D only.
        resolution (str): time frame, default is 1D, possible values: 1, 15, 30, 60, 1D
        decor (bool): True to rename columns to Open, High, Low, Close, Volume, Date which is compatible with popular python packages for finance, False to keep original column names
    """
    # convert from_date, to_date to timestamp
    start_timestamp = parse_timestamp(start_date)
    if end_date == last_n_days(0) or end_date.split(' ')[0] == last_n_days(0):
        if resolution in ['1D', 'D']:
            end_timestamp = parse_timestamp(end_date.split(' ')[0] + ' 15:00:00')
            if start_date == last_n_days(0) or start_date.split(' ')[0] == last_n_days(0):
                start_timestamp = parse_timestamp(start_date) - 86400
            if time_in_date_string(start_date, print_errors=False) == True or time_in_date_string(end_date, print_errors=False) == True:
                print ('Output data is incomplete; it\'s based on your specified timeframe and, for daily resolution, use a date string without a time component.')
        else:
            if time_in_date_string(end_date, print_errors=False) == False:
                end_timestamp = parse_timestamp(end_date + ' 15:00:00')
                if time_in_date_string(start_date, print_errors=False) == True:
                    print('Be careful! Output data is incomplete; time aware in your start_date and end_date, for daily resolution, use a date string without a time component.')
            else:
                end_timestamp = parse_timestamp(end_date)
    else:
        if resolution not in ['D', '1D']:
            if time_in_date_string(end_date, print_errors=False) == False:
                end_timestamp = parse_timestamp(end_date + ' 15:00:00')
            else:
                end_timestamp = parse_timestamp(end_date)
        else:
            end_timestamp = parse_timestamp(end_date)
    url = f"https://iboard.ssi.com.vn/dchart/api/history?resolution={resolution}&symbol={symbol}&from={start_timestamp}&to={end_timestamp}"
    response = requests.request("GET", url, headers=headers, data={})
    columns_name={'t': 'Time', 'o': 'Open', 'h': 'High', 'l': 'Low', 'c': 'Close', 'v': 'Volume'}
    if response.status_code == 200:
        print("Request successful")
        data = response.json()
        df = pd.DataFrame(data)
        # drop q, s, nextTime columns
        df.drop(columns=['s'], inplace=True)
        # convert t from timestamp to datetime
        df['t'] = pd.to_datetime(df['t'], unit='s')
        # convert t to local timezone
        df['t'] = df['t'].dt.tz_localize('UTC').dt.tz_convert('Asia/Ho_Chi_Minh')
        # remove timezone info
        df['t'] = df['t'].dt.tz_localize(None)
        # set volume to int
        df['v'] = pd.to_numeric(df['v'], errors='coerce').fillna(0).astype(int) # Dữ liệu ssi cho VNINDEX có chứa giá trị NaN cho cột volume
        # arrange columns order
        df = df[['t', 'o', 'h', 'l', 'c', 'v']]
        # if resolution is 1D, set t to date only
        if resolution in ['1D', 'D']: # and time_in_date_string(start_date, False) == False and time_in_date_string(end_date, False) == False
            df['t'] = df['t'].dt.date
        # rename columns o, h, l, c, v, t to Open, High, Low, Close, Volume, Date
        if decor == True:
            df.rename(columns=columns_name, inplace=True)
            # set Time to index
            df.set_index('Time', inplace=True)
        elif decor == False:
            # lowercase column names from columns_name dict
            df.rename(columns={k: v.lower() for k, v in columns_name.items()}, inplace=True)
            df.set_index('time', inplace=True)
        # add a ticker column
        df['ticker'] = symbol
        # convert df columns open, high, low, close, volume to float, volume to int
        df[['open', 'high', 'low', 'close']] = df[['open', 'high', 'low', 'close']].astype(float)
        return df
    else:
        print(f"Request failed: {response.text}")
        return None
    

def hsc_ohlc (symbol='HCM', resolution="1D", start_date="2023-01-01", end_date="2023-10-31", decor=True, headers=hsc_headers):
    """
    Get OHLC historical data from HSC API
    Parameters:
        symbol (str): stock symbol
        resolution (str): time frame, default is 1D, possible values: 1, 1D
        start_date (str): start date, format YYYY-MM-DD
        end_date (str): end date, format YYYY-MM-DD
        decor (bool): True to rename columns to Open, High, Low, Close, Volume, Date which is compatible with popular python packages for finance, False to keep original column names
    """
    url = "https://streaming-api.hsc.com.vn/api/DataFeed/GetChartData"
    # convert start_date and end_date to timestamp
    start_date_stamp = int(datetime.strptime(start_date, "%Y-%m-%d").timestamp())
    end_date_stamp = int(datetime.strptime(end_date, "%Y-%m-%d").timestamp())
    # add 1 day to end_date_stamp to include end_date
    end_date_stamp += 86400
    payload = json.dumps({
              "quote": symbol,
              "market": "S",
              "resolution": resolution,
              "beginTime": start_date_stamp,
              "endTime": end_date_stamp,
              "coreType": -1
              })
    response = requests.request("POST", url, headers=headers, data=payload)
    columns_name={'t': 'Time', 'o': 'Open', 'h': 'High', 'l': 'Low', 'c': 'Close', 'v': 'Volume'}
    if response.status_code == 200:
        print("Request successful")
        data = response.json()
        df = pd.DataFrame(data['result'][0])
        # drop q, s, nextTime columns
        df.drop(columns=['q', 's', 'nextTime'], inplace=True)
        # convert t from timestamp to datetime
        df['t'] = pd.to_datetime(df['t'], unit='s')
        # convert t to local timezone
        df['t'] = df['t'].dt.tz_localize('UTC').dt.tz_convert('Asia/Ho_Chi_Minh')
        # remove timezone info
        df['t'] = df['t'].dt.tz_localize(None)
        # set volume to int
        df['v'] = df['v'].astype(int)
        # if resolution is 1D, set t to date only
        if resolution == "1D":
            df['t'] = df['t'].dt.date
        # rename columns o, h, l, c, v, t to Open, High, Low, Close, Volume, Date
        if decor == True:
            df.rename(columns=columns_name, inplace=True)
            # set Time to index
            df.set_index('Time', inplace=True)
        elif decor == False:
            # lowercase column names from columns_name dict
            df.rename(columns={k: v.lower() for k, v in columns_name.items()}, inplace=True)
            df.set_index('time', inplace=True)
        # filter data by start_date and end_date again. convert start_date and end_date to datetime date first
        start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
        df = df.loc[start_date:]
        # add a ticker column
        df['ticker'] = symbol
        # convert df columns open, high, low, close, volume to float, volume to int
        df[['open', 'high', 'low', 'close']] = df[['open', 'high', 'low', 'close']].astype(float)
        df['volume'] = df['volume'].astype(int)
        return df
    else:
        print(f"Request failed: {response.text}")
        return None
    

def vnd_ohlc (symbol='VND', start_date='2023-06-01', end_date='2023-06-17', resolution='1D', decor=False, headers=vnd_headers):
    """
    Get OHLC historical data from VND API
    Parameters:
        symbol (str): stock symbol
        resolution (str): time frame, default is 1D, possible values: 1, 15, 30, 60, 1D
        start_date (str): start date, format YYYY-MM-DD
        end_date (str): end date, format YYYY-MM-DD
        decor (bool): True to rename columns to Open, High, Low, Close, Volume, Date which is compatible with popular python packages for finance, False to keep original column names
    """
    # convert 1D to D
    if resolution == "1D":
        resolution = "D"
    # add one more day to end_date
    end_date = (datetime.strptime(end_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
    # convert from_date, to_date to timestamp
    start_timestamp = int(datetime.strptime(start_date, '%Y-%m-%d').timestamp())
    end_timestamp = int(datetime.strptime(end_date, '%Y-%m-%d').timestamp())
    url = f"https://dchart-api.vndirect.com.vn/dchart/history?resolution={resolution}&symbol={symbol}&from={start_timestamp}&to={end_timestamp}"
    response = requests.request("GET", url, headers=headers, data={})
    columns_name={'t': 'Time', 'o': 'Open', 'h': 'High', 'l': 'Low', 'c': 'Close', 'v': 'Volume'}
    if response.status_code == 200:
        print("Request successful")
        data = response.json()
        df = pd.DataFrame(data)
        # drop q, s, nextTime columns
        df.drop(columns=['s'], inplace=True)
        # convert t from timestamp to datetime
        df['t'] = pd.to_datetime(df['t'], unit='s')
        # convert t to local timezone
        df['t'] = df['t'].dt.tz_localize('UTC').dt.tz_convert('Asia/Ho_Chi_Minh')
        # remove timezone info
        df['t'] = df['t'].dt.tz_localize(None)
        # set volume to int
        df['v'] = df['v'].astype(int)
        # arrange columns order
        df = df[['t', 'o', 'h', 'l', 'c', 'v']]
        # if resolution is 1D, set t to date only
        if resolution == "D":
            df['t'] = df['t'].dt.date
        # rename columns o, h, l, c, v, t to Open, High, Low, Close, Volume, Date
        if decor == True:
            df.rename(columns=columns_name, inplace=True)
            # set Time to index
            df.set_index('Time', inplace=True)
        elif decor == False:
            # lowercase column names from columns_name dict
            df.rename(columns={k: v.lower() for k, v in columns_name.items()}, inplace=True)
            df.set_index('time', inplace=True)
        # filter data by start_date and end_date again. convert start_date and end_date to datetime date first
        start_date = datetime.strptime(start_date, "%Y-%m-%d").date()
        end_date = datetime.strptime(end_date, "%Y-%m-%d").date()
        df = df.loc[start_date:]
        # add a ticker column
        df['ticker'] = symbol
        # convert df columns open, high, low, close, volume to float, volume to int
        df[['open', 'high', 'low', 'close']] = df[['open', 'high', 'low', 'close']].astype(float)
        df['volume'] = df['volume'].astype(int)
        return df
    else:
        print(f"Request failed: {response.text}")
        return None
