## 1/1/2024

- Bổ sung Demo notebook cho Pytesseract OCR sử dụng để chuyển đổi tài liệu scan sang văn bản
- Bổ sung các hàm trích xuất thông tin tài liệu sử dụng để tải về từ API của Vietstock Finance
- Cấu trúc lại trang hướng dẫn README

## 23/12/2023
> Cập nhật cho gói phần mềm bổ sung `vnstock-data-pro`, phiên bản 0.0.3

- Bổ sung hàm truy xuất dữ liệu giao dịch nước ngoài `foreign_trade_data` và tự doanh `proprietary_trade_data`
- Cập nhật tài liệu hướng dẫn sử dụng

## 15/12/2023
- Bổ sung khả năng kết nối nguồn dữ liệu từ SSI Fast Connect Data, hỗ trợ streaming dữ liệu trong thời gian thực.

## 12/12/2023
- Ra mắt phiên bản `vnstock-data-pro` 0.0.1 nội bộ cho chương trình Vnstock Insiders
- Bổ sung các nguồn dữ liệu giá lịch sử từ SSI, VNDirect, HSC